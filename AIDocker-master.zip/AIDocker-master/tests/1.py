# coding=utf-8
import cv2
import numpy as np
import os
import sys
import unittest

root = os.path.abspath(os.path.expanduser(__file__ + '/../..'))
sys.path.append(root)
path = root + '/data/'
img = cv2.imread(path+'cat_sy_2.png', 0)


# OpenCV定义的结构元素
kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
print(kernel)

cv2.imshow('img',img)
cv2.waitKey(0)
# 腐蚀图像
eroded = cv2.erode(img, kernel)
# 显示腐蚀后的图像
cv2.imshow("Eroded Image", eroded);
cv2.waitKey(0)

# 膨胀图像
dilated = cv2.dilate(img, kernel)
# 显示膨胀后的图像
cv2.imshow("Dilated Image", dilated);
cv2.waitKey(0)
# 原图像
cv2.imshow("Origin", img)
cv2.waitKey(0)

# NumPy定义的结构元素
NpKernel = np.uint8(np.ones((5, 5)))
print(NpKernel)
Nperoded = cv2.erode(img, NpKernel)

# 显示腐蚀后的图像
cv2.imshow("Eroded by NumPy kernel", Nperoded);

cv2.waitKey(0)
cv2.destroyAllWindows()